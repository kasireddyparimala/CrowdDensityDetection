# CrowdDensityDetection > 2025-05-22 8:00pm
https://universe.roboflow.com/parimala/crowddensitydetection

Provided by a Roboflow user
License: CC BY 4.0

